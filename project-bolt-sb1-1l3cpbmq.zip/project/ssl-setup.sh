#!/bin/bash

# SSL Certificate Setup Script using Let's Encrypt
# For J&T&C Fashion E-commerce production deployment

DOMAIN="your-domain.com"
EMAIL="your-email@domain.com"

echo "🔒 Setting up SSL certificates for J&T&C Fashion E-commerce..."

# Update system
sudo apt update

# Install Certbot and Nginx plugin
sudo apt install -y certbot python3-certbot-nginx

# Install Nginx if not already installed
sudo apt install -y nginx

# Stop Nginx temporarily for certificate generation
sudo systemctl stop nginx

# Generate SSL certificate
sudo certbot certonly --standalone \
    --email $EMAIL \
    --agree-tos \
    --no-eff-email \
    --domains $DOMAIN,www.$DOMAIN

# Generate strong DH parameters
sudo openssl dhparam -out /etc/nginx/dhparam.pem 2048

# Set up automatic renewal
sudo crontab -l | { cat; echo "0 12 * * * /usr/bin/certbot renew --quiet"; } | sudo crontab -

# Create renewal hook to reload Nginx
sudo mkdir -p /etc/letsencrypt/renewal-hooks/deploy
sudo tee /etc/letsencrypt/renewal-hooks/deploy/nginx-reload.sh > /dev/null <<EOF
#!/bin/bash
systemctl reload nginx
EOF
sudo chmod +x /etc/letsencrypt/renewal-hooks/deploy/nginx-reload.sh

# Test automatic renewal
sudo certbot renew --dry-run

echo "✅ SSL certificates generated successfully!"
echo ""
echo "📋 Certificate locations:"
echo "Certificate: /etc/letsencrypt/live/$DOMAIN/fullchain.pem"
echo "Private Key: /etc/letsencrypt/live/$DOMAIN/privkey.pem"
echo "Chain: /etc/letsencrypt/live/$DOMAIN/chain.pem"
echo ""
echo "🔄 Auto-renewal is set up via cron job"
echo "Test renewal: sudo certbot renew --dry-run"