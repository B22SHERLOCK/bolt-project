#!/bin/bash

# UFW (Uncomplicated Firewall) Setup Script for J&T&C Fashion E-commerce
# This script configures a secure firewall for production deployment

echo "🔥 Setting up UFW Firewall for J&T&C Fashion E-commerce..."

# Reset UFW to defaults
sudo ufw --force reset

# Set default policies
sudo ufw default deny incoming
sudo ufw default allow outgoing

# Allow SSH (adjust port if you use non-standard SSH port)
sudo ufw allow 22/tcp comment 'SSH'

# Allow HTTP and HTTPS
sudo ufw allow 80/tcp comment 'HTTP'
sudo ufw allow 443/tcp comment 'HTTPS'

# Allow specific application ports if needed
# sudo ufw allow 3000/tcp comment 'Node.js App'
# sudo ufw allow 5432/tcp comment 'PostgreSQL'
# sudo ufw allow 6379/tcp comment 'Redis'

# Rate limiting for SSH to prevent brute force
sudo ufw limit ssh comment 'SSH Rate Limiting'

# Allow specific IP ranges for admin access (replace with your IPs)
# sudo ufw allow from YOUR_OFFICE_IP to any port 22 comment 'Office SSH'
# sudo ufw allow from YOUR_HOME_IP to any port 22 comment 'Home SSH'

# Block common attack ports
sudo ufw deny 23/tcp comment 'Block Telnet'
sudo ufw deny 135/tcp comment 'Block RPC'
sudo ufw deny 139/tcp comment 'Block NetBIOS'
sudo ufw deny 445/tcp comment 'Block SMB'
sudo ufw deny 1433/tcp comment 'Block MSSQL'
sudo ufw deny 3389/tcp comment 'Block RDP'

# Enable logging
sudo ufw logging on

# Enable UFW
sudo ufw --force enable

# Show status
echo "🔥 UFW Status:"
sudo ufw status verbose

echo "✅ UFW Firewall setup complete!"
echo ""
echo "📋 Next steps:"
echo "1. Review the firewall rules above"
echo "2. Test your application connectivity"
echo "3. Monitor logs: sudo tail -f /var/log/ufw.log"
echo "4. Add specific IP whitelist rules as needed"
echo ""
echo "⚠️  Important: Make sure you can still access your server via SSH!"