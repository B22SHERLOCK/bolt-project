import React from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import ProductShowcase from './components/ProductShowcase';
import FloatingElements from './components/FloatingElements';

function App() {
  return (
    <div className="min-h-screen bg-slate-900 text-white overflow-x-hidden">
      {/* Floating Background Elements */}
      <FloatingElements />
      
      {/* Header */}
      <Header />
      
      {/* Main Content */}
      <main>
        <Hero />
        <ProductShowcase />
      </main>
      
      {/* Footer */}
      <footer className="relative py-12 px-4 sm:px-6 lg:px-8 bg-gradient-to-t from-slate-900 to-slate-800 border-t border-purple-500/20">
        <div className="max-w-7xl mx-auto text-center">
          <div className="flex items-center justify-center space-x-2 mb-6">
            <div className="w-8 h-8 bg-gradient-to-br from-purple-500 to-cyan-500 rounded-lg flex items-center justify-center">
              <div className="w-4 h-4 bg-white rounded-sm transform rotate-45" />
            </div>
            <span className="text-2xl font-bold bg-gradient-to-r from-purple-400 to-cyan-400 bg-clip-text text-transparent">
              J&T&C
            </span>
          </div>
          <p className="text-white/70 mb-4">
            Redefining fashion through quantum design and ethereal technology.
          </p>
          <p className="text-white/50 text-sm">
            © 2025 J&T&C Fashion. All rights reserved. Crafted in the metaverse.
          </p>
        </div>
      </footer>
    </div>
  );
}

export default App;