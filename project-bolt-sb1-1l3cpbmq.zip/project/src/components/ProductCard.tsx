import React from 'react';
import { motion } from 'framer-motion';
import { ShoppingBag, Heart, Eye } from 'lucide-react';
import { Product } from '../types';

interface ProductCardProps {
  product: Product;
  index: number;
}

const ProductCard: React.FC<ProductCardProps> = ({ product, index }) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 50 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6, delay: index * 0.1 }}
      whileHover={{ 
        y: -20, 
        rotateX: 5,
        rotateY: 5,
        scale: 1.02,
        transition: { duration: 0.3 }
      }}
      className="group relative bg-gradient-to-br from-slate-800/50 to-slate-900/50 backdrop-blur-md rounded-3xl overflow-hidden border border-purple-500/20 shadow-2xl hover:shadow-purple-500/25 transform perspective-1000"
    >
      {/* Glow Effect */}
      <div className="absolute inset-0 bg-gradient-to-br from-purple-500/0 via-purple-500/5 to-cyan-500/10 opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
      
      {/* Featured Badge */}
      {product.featured && (
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ delay: 0.5 }}
          className="absolute top-4 left-4 z-10 px-3 py-1 bg-gradient-to-r from-amber-500 to-orange-500 text-white text-xs font-bold rounded-full flex items-center space-x-1"
        >
          <div className="w-2 h-2 bg-white rounded-full animate-pulse" />
          <span>FEATURED</span>
        </motion.div>
      )}

      {/* Product Image */}
      <div className="relative h-80 overflow-hidden">
        <motion.img
          whileHover={{ scale: 1.1 }}
          transition={{ duration: 0.5 }}
          src={product.image}
          alt={product.title}
          className="w-full h-full object-cover"
        />
        
        {/* Overlay Actions */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end justify-center pb-6">
          <div className="flex space-x-3">
            {[
              { icon: Eye, label: 'Quick View' },
              { icon: Heart, label: 'Add to Wishlist' },
              { icon: ShoppingBag, label: 'Add to Cart' }
            ].map(({ icon: Icon, label }, actionIndex) => (
              <motion.button
                key={label}
                initial={{ y: 50, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: actionIndex * 0.1 }}
                whileHover={{ scale: 1.1, y: -2 }}
                whileTap={{ scale: 0.95 }}
                className="p-3 bg-white/10 backdrop-blur-md rounded-full text-white hover:bg-purple-500/30 transition-all duration-300 group/btn"
                title={label}
              >
                <Icon size={16} className="group-hover/btn:scale-110 transition-transform duration-200" />
              </motion.button>
            ))}
          </div>
        </div>

        {/* Floating Price Tag */}
        <motion.div
          whileHover={{ scale: 1.05, rotate: 5 }}
          className="absolute top-4 right-4 bg-gradient-to-r from-purple-600/90 to-pink-600/90 backdrop-blur-md text-white px-3 py-2 rounded-2xl font-bold shadow-lg"
        >
          <div className="text-lg">${product.price}</div>
          {product.originalPrice && (
            <div className="text-xs line-through opacity-70">${product.originalPrice}</div>
          )}
        </motion.div>
      </div>

      {/* Product Info */}
      <div className="p-6 space-y-4">
        <div>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.3 }}
            className="text-xs font-semibold text-purple-400 uppercase tracking-wider mb-2"
          >
            {product.category.replace('-', ' ')}
          </motion.div>
          
          <motion.h3
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="text-xl font-bold text-white mb-2 group-hover:text-purple-300 transition-colors duration-300"
          >
            {product.title}
          </motion.h3>
          
          <motion.p
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
            className="text-white/70 text-sm leading-relaxed line-clamp-3"
          >
            {product.description}
          </motion.p>
        </div>

        {/* Action Button */}
        <motion.button
          whileHover={{ scale: 1.02, boxShadow: "0 10px 30px rgba(139, 92, 246, 0.3)" }}
          whileTap={{ scale: 0.98 }}
          className="w-full py-3 bg-gradient-to-r from-purple-600 to-pink-600 text-white font-semibold rounded-xl hover:from-purple-700 hover:to-pink-700 transition-all duration-300 flex items-center justify-center space-x-2 group/btn"
        >
          <ShoppingBag size={16} className="group-hover/btn:scale-110 transition-transform duration-200" />
          <span>Add to Cart</span>
        </motion.button>
      </div>

      {/* Ambient Glow */}
      <div className="absolute -inset-0.5 bg-gradient-to-r from-purple-600/20 to-pink-600/20 rounded-3xl blur opacity-0 group-hover:opacity-100 transition-opacity duration-500 -z-10" />
    </motion.div>
  );
};

export default ProductCard;