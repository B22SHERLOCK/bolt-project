import React from 'react';
import { motion } from 'framer-motion';

const FloatingElements: React.FC = () => {
  return (
    <div className="fixed inset-0 pointer-events-none z-0 overflow-hidden">
      {/* Floating Geometric Shapes */}
      <motion.div
        className="absolute top-20 left-10 w-16 h-16 bg-gradient-to-br from-purple-500/20 to-cyan-500/20 rounded-full backdrop-blur-sm"
        animate={{
          y: [-20, 20, -20],
          x: [0, 15, 0],
          rotate: [0, 180, 360],
        }}
        transition={{
          duration: 8,
          repeat: Infinity,
          ease: "easeInOut",
        }}
      />
      
      <motion.div
        className="absolute top-40 right-20 w-12 h-12 bg-gradient-to-br from-cyan-400/30 to-blue-600/30 transform rotate-45 backdrop-blur-sm"
        animate={{
          y: [15, -15, 15],
          x: [-10, 10, -10],
          rotate: [45, 225, 405],
        }}
        transition={{
          duration: 6,
          repeat: Infinity,
          ease: "easeInOut",
          delay: 1,
        }}
      />

      <motion.div
        className="absolute bottom-32 left-1/4 w-20 h-20 bg-gradient-to-br from-amber-400/20 to-orange-500/20 rounded-full backdrop-blur-sm"
        animate={{
          y: [10, -30, 10],
          x: [0, 20, 0],
          scale: [1, 1.2, 1],
        }}
        transition={{
          duration: 10,
          repeat: Infinity,
          ease: "easeInOut",
          delay: 2,
        }}
      />

      {/* Floating Cloth Animation */}
      <motion.div
        className="absolute top-1/3 right-10 w-32 h-48 opacity-30"
        animate={{
          y: [-10, 10, -10],
          x: [0, -5, 0],
        }}
        transition={{
          duration: 4,
          repeat: Infinity,
          ease: "easeInOut",
        }}
      >
        <div className="w-full h-full bg-gradient-to-b from-purple-300/40 to-transparent rounded-t-full transform skew-x-12 backdrop-blur-sm shadow-2xl" />
      </motion.div>

      <motion.div
        className="absolute bottom-20 right-1/3 w-24 h-36 opacity-25"
        animate={{
          y: [5, -15, 5],
          x: [0, 8, 0],
          rotate: [0, 5, 0],
        }}
        transition={{
          duration: 5,
          repeat: Infinity,
          ease: "easeInOut",
          delay: 1.5,
        }}
      >
        <div className="w-full h-full bg-gradient-to-b from-cyan-300/40 to-transparent rounded-t-full transform -skew-x-6 backdrop-blur-sm shadow-xl" />
      </motion.div>

      {/* Ambient Light Orbs */}
      <motion.div
        className="absolute top-1/2 left-1/2 w-96 h-96 bg-gradient-radial from-purple-500/10 via-transparent to-transparent rounded-full"
        animate={{
          scale: [1, 1.2, 1],
          opacity: [0.3, 0.6, 0.3],
        }}
        transition={{
          duration: 8,
          repeat: Infinity,
          ease: "easeInOut",
        }}
      />
    </div>
  );
};

export default FloatingElements;