import { Product } from '../types';

export const products: Product[] = [
  {
    id: 1,
    title: "Quantum Weave T-Shirt",
    image: "https://images.pexels.com/photos/1020585/pexels-photo-1020585.jpeg",
    price: 89,
    originalPrice: 120,
    description: "Engineered with nano-fiber technology for ultimate comfort and style. Features moisture-wicking properties and adaptive fit.",
    category: "t-shirts",
    featured: true
  },
  {
    id: 2,
    title: "Neural Network Hoodie",
    image: "https://images.pexels.com/photos/1040945/pexels-photo-1040945.jpeg",
    price: 159,
    description: "Advanced thermal regulation with embedded micro-circuits for temperature control. Sustainable bio-fabric construction.",
    category: "shirts"
  },
  {
    id: 3,
    title: "Holographic Denim",
    image: "https://images.pexels.com/photos/1007018/pexels-photo-1007018.jpeg",
    price: 199,
    originalPrice: 250,
    description: "Color-shifting smart denim with self-repairing nano-threads. Adapts to light conditions for optimal visual impact.",
    category: "pants",
    featured: true
  },
  {
    id: 4,
    title: "Ethereal Silk Shirt",
    image: "https://images.pexels.com/photos/1040949/pexels-photo-1040949.jpeg",
    price: 234,
    description: "Bioengineered silk proteins with luminescent properties. Changes opacity based on ambient light and mood.",
    category: "shirts"
  },
  {
    id: 5,
    title: "Cyberpunk Cargo Pants",
    image: "https://images.pexels.com/photos/1124465/pexels-photo-1124465.jpeg",
    price: 178,
    description: "Multi-dimensional storage with quantum compression pockets. Reinforced with graphene fibers for durability.",
    category: "pants"
  },
  {
    id: 6,
    title: "Neon Genesis Tee",
    image: "https://images.pexels.com/photos/1040960/pexels-photo-1040960.jpeg",
    price: 94,
    originalPrice: 125,
    description: "Photoreactive fabric that glows in low light conditions. Embedded with bioluminescent threads for unique patterns.",
    category: "t-shirts",
    featured: true
  },
  {
    id: 7,
    title: "Plasma Wave Shirt",
    image: "https://images.pexels.com/photos/1040966/pexels-photo-1040966.jpeg",
    price: 167,
    description: "Dynamic pattern generation through electromagnetic thread weaving. Creates unique visual effects in motion.",
    category: "shirts"
  },
  {
    id: 8,
    title: "Zero-G Joggers",
    image: "https://images.pexels.com/photos/1124466/pexels-photo-1124466.jpeg",
    price: 145,
    description: "Anti-gravity fiber simulation with weightless feel. Memory foam padding adapts to body movement.",
    category: "pants"
  }
];