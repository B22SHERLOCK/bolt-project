export interface Product {
  id: number;
  title: string;
  image: string;
  price: number;
  originalPrice?: number;
  description: string;
  category: 'shirts' | 'pants' | 't-shirts';
  featured?: boolean;
}

export interface FloatingElement {
  id: number;
  type: 'geometric' | 'cloth';
  size: 'small' | 'medium' | 'large';
  position: {
    x: number;
    y: number;
  };
  animation: {
    duration: number;
    delay: number;
  };
}