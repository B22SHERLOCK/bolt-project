#!/bin/bash

# Production Deployment Script for J&T&C Fashion E-commerce
# This script handles secure deployment with all security measures

set -e  # Exit on any error

# Configuration
DOMAIN="your-domain.com"
APP_DIR="/var/www/jtc-fashion"
BACKUP_DIR="/var/backups/jtc-fashion"
LOG_FILE="/var/log/jtc-deploy.log"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Logging function
log() {
    echo -e "${GREEN}[$(date +'%Y-%m-%d %H:%M:%S')] $1${NC}" | tee -a $LOG_FILE
}

error() {
    echo -e "${RED}[$(date +'%Y-%m-%d %H:%M:%S')] ERROR: $1${NC}" | tee -a $LOG_FILE
    exit 1
}

warn() {
    echo -e "${YELLOW}[$(date +'%Y-%m-%d %H:%M:%S')] WARNING: $1${NC}" | tee -a $LOG_FILE
}

# Check if running as root
if [[ $EUID -eq 0 ]]; then
   error "This script should not be run as root for security reasons"
fi

log "🚀 Starting J&T&C Fashion E-commerce deployment..."

# Create backup
log "📦 Creating backup..."
sudo mkdir -p $BACKUP_DIR
if [ -d "$APP_DIR" ]; then
    sudo tar -czf "$BACKUP_DIR/backup-$(date +%Y%m%d-%H%M%S).tar.gz" -C "$APP_DIR" .
    log "✅ Backup created successfully"
fi

# Update system packages
log "📦 Updating system packages..."
sudo apt update && sudo apt upgrade -y

# Install required packages
log "📦 Installing required packages..."
sudo apt install -y nginx nodejs npm certbot python3-certbot-nginx ufw fail2ban

# Setup UFW firewall
log "🔥 Configuring UFW firewall..."
chmod +x ufw-setup.sh
./ufw-setup.sh

# Setup SSL certificates
log "🔒 Setting up SSL certificates..."
chmod +x ssl-setup.sh
./ssl-setup.sh

# Create application directory
log "📁 Setting up application directory..."
sudo mkdir -p $APP_DIR
sudo chown -R $USER:$USER $APP_DIR

# Copy application files
log "📋 Copying application files..."
cp -r dist/* $APP_DIR/
cp .env.example $APP_DIR/.env

# Set proper permissions
log "🔐 Setting file permissions..."
sudo chown -R www-data:www-data $APP_DIR
sudo chmod -R 755 $APP_DIR
sudo chmod 600 $APP_DIR/.env

# Configure Nginx
log "🌐 Configuring Nginx..."
sudo cp nginx.conf /etc/nginx/sites-available/jtc-fashion
sudo ln -sf /etc/nginx/sites-available/jtc-fashion /etc/nginx/sites-enabled/
sudo rm -f /etc/nginx/sites-enabled/default

# Test Nginx configuration
sudo nginx -t || error "Nginx configuration test failed"

# Configure fail2ban
log "🛡️  Configuring fail2ban..."
sudo tee /etc/fail2ban/jail.local > /dev/null <<EOF
[DEFAULT]
bantime = 3600
findtime = 600
maxretry = 3

[sshd]
enabled = true
port = ssh
logpath = /var/log/auth.log
maxretry = 3

[nginx-http-auth]
enabled = true
filter = nginx-http-auth
logpath = /var/log/nginx/error.log
maxretry = 3

[nginx-limit-req]
enabled = true
filter = nginx-limit-req
logpath = /var/log/nginx/error.log
maxretry = 3
EOF

# Start services
log "🔄 Starting services..."
sudo systemctl enable nginx
sudo systemctl enable fail2ban
sudo systemctl restart nginx
sudo systemctl restart fail2ban

# Setup log rotation
log "📝 Setting up log rotation..."
sudo tee /etc/logrotate.d/jtc-fashion > /dev/null <<EOF
/var/log/nginx/jtc-fashion.*.log {
    daily
    missingok
    rotate 52
    compress
    delaycompress
    notifempty
    create 644 www-data www-data
    postrotate
        systemctl reload nginx
    endscript
}
EOF

# Setup monitoring
log "📊 Setting up basic monitoring..."
sudo tee /etc/cron.d/jtc-monitoring > /dev/null <<EOF
# Check disk space every hour
0 * * * * root df -h | awk 'NR>1 && \$5+0 > 80 {print "Disk space warning: " \$0}' | mail -s "Disk Space Alert" admin@$DOMAIN

# Check memory usage every hour  
0 * * * * root free -m | awk 'NR==2{printf "Memory Usage: %s/%sMB (%.2f%%)\n", \$3,\$2,\$3*100/\$2 }' | awk '{if(\$NF > 80) print}' | mail -s "Memory Alert" admin@$DOMAIN

# Check SSL certificate expiry weekly
0 0 * * 0 root openssl x509 -in /etc/letsencrypt/live/$DOMAIN/cert.pem -noout -checkend 2592000 || echo "SSL certificate expires soon" | mail -s "SSL Certificate Alert" admin@$DOMAIN
EOF

# Final security check
log "🔍 Running final security checks..."

# Check file permissions
find $APP_DIR -type f -perm /o+w -exec echo "World-writable file found: {}" \;

# Check for sensitive files
if [ -f "$APP_DIR/.env" ]; then
    if [ "$(stat -c %a $APP_DIR/.env)" != "600" ]; then
        warn "Environment file permissions are not secure"
    fi
fi

# Test application
log "🧪 Testing application..."
if curl -f -s http://localhost/health > /dev/null; then
    log "✅ Application health check passed"
else
    warn "Application health check failed"
fi

# Display final status
log "🎉 Deployment completed successfully!"
echo ""
echo "📋 Deployment Summary:"
echo "• Domain: $DOMAIN"
echo "• Application Directory: $APP_DIR"
echo "• SSL Certificate: Enabled"
echo "• Firewall: UFW Enabled"
echo "• Fail2ban: Enabled"
echo "• Nginx: Running"
echo ""
echo "🔧 Next Steps:"
echo "1. Update DNS records to point to this server"
echo "2. Configure Cloudflare WAF rules"
echo "3. Set up monitoring and alerting"
echo "4. Test all functionality"
echo "5. Update .env file with production values"
echo ""
echo "📊 Monitor your application:"
echo "• Nginx logs: sudo tail -f /var/log/nginx/jtc-fashion.*.log"
echo "• UFW logs: sudo tail -f /var/log/ufw.log"
echo "• Fail2ban: sudo fail2ban-client status"
echo ""
log "🚀 J&T&C Fashion E-commerce is now live and secure!"