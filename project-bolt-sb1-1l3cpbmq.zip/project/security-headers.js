// Security Headers Middleware for Express.js
// Production-ready security configuration for J&T&C Fashion E-commerce

const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const slowDown = require('express-slow-down');

// Rate limiting configuration
const createRateLimit = (windowMs, max, message) => rateLimit({
  windowMs,
  max,
  message: { error: message },
  standardHeaders: true,
  legacyHeaders: false,
  handler: (req, res) => {
    res.status(429).json({
      error: 'Too many requests',
      retryAfter: Math.round(windowMs / 1000)
    });
  }
});

// Speed limiting configuration
const createSpeedLimit = (windowMs, delayAfter, delayMs) => slowDown({
  windowMs,
  delayAfter,
  delayMs,
  maxDelayMs: delayMs * 10
});

// Security middleware configuration
const securityMiddleware = (app) => {
  // Helmet for security headers
  app.use(helmet({
    contentSecurityPolicy: {
      directives: {
        defaultSrc: ["'self'"],
        styleSrc: [
          "'self'",
          "'unsafe-inline'",
          "https://fonts.googleapis.com",
          "https://cdnjs.cloudflare.com"
        ],
        scriptSrc: [
          "'self'",
          "'unsafe-inline'",
          "'unsafe-eval'",
          "https://cdnjs.cloudflare.com",
          "https://cdn.jsdelivr.net"
        ],
        fontSrc: [
          "'self'",
          "https://fonts.gstatic.com",
          "https://cdnjs.cloudflare.com"
        ],
        imgSrc: [
          "'self'",
          "data:",
          "https:",
          "blob:"
        ],
        connectSrc: [
          "'self'",
          "https:"
        ],
        mediaSrc: ["'self'"],
        objectSrc: ["'none'"],
        childSrc: ["'self'"],
        frameAncestors: ["'none'"],
        formAction: ["'self'"],
        baseUri: ["'self'"]
      }
    },
    crossOriginEmbedderPolicy: false,
    hsts: {
      maxAge: 31536000,
      includeSubDomains: true,
      preload: true
    }
  }));

  // Additional security headers
  app.use((req, res, next) => {
    // Remove server information
    res.removeHeader('X-Powered-By');
    
    // Additional security headers
    res.setHeader('X-Frame-Options', 'DENY');
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
    res.setHeader('Permissions-Policy', 
      'geolocation=(), microphone=(), camera=(), payment=(), usb=(), ' +
      'magnetometer=(), gyroscope=(), speaker=(), vibrate=(), fullscreen=(self)'
    );
    
    next();
  });

  // Rate limiting for different endpoints
  app.use('/api/', createRateLimit(15 * 60 * 1000, 100, 'Too many API requests'));
  app.use('/auth/', createRateLimit(15 * 60 * 1000, 5, 'Too many authentication attempts'));
  app.use('/login', createRateLimit(15 * 60 * 1000, 5, 'Too many login attempts'));
  app.use('/register', createRateLimit(60 * 60 * 1000, 3, 'Too many registration attempts'));

  // Speed limiting for API routes
  app.use('/api/', createSpeedLimit(15 * 60 * 1000, 50, 500));

  // General rate limiting
  app.use(createRateLimit(15 * 60 * 1000, 1000, 'Too many requests from this IP'));
};

module.exports = securityMiddleware;