# J&T&C Fashion E-commerce

A production-ready 3D futuristic fashion e-commerce website with comprehensive security features.

## 🚀 Features

- **3D Futuristic Design**: Surreal minimalist aesthetic with floating elements
- **Responsive Layout**: Mobile-first design with elegant animations
- **Production Security**: HTTPS, WAF, firewall, and security headers
- **Performance Optimized**: Gzip/Brotli compression, caching, CDN ready

## 🔒 Security Features

- **HTTPS/SSL**: Let's Encrypt certificates with auto-renewal
- **Web Application Firewall**: Cloudflare WAF with custom rules
- **Server Firewall**: UFW configuration with rate limiting
- **Security Headers**: Comprehensive HTTP security headers
- **Environment Protection**: Secure environment variable handling
- **Rate Limiting**: API and authentication endpoint protection
- **Fail2ban**: Intrusion prevention system

## 📦 Quick Start

### Development
```bash
npm install
npm run dev
```

### Production Deployment
```bash
# 1. Clone repository
git clone <repository-url>
cd jtc-fashion

# 2. Configure environment
cp .env.example .env
# Edit .env with your production values

# 3. Run deployment script
chmod +x deploy.sh
./deploy.sh
```

## 🛠️ Configuration

### Environment Variables
Copy `.env.example` to `.env` and configure:
- Database credentials
- API keys (Stripe, email, etc.)
- Security tokens
- Cloudflare settings

### Domain Setup
1. Update domain in configuration files:
   - `nginx.conf`
   - `ssl-setup.sh`
   - `deploy.sh`
2. Point DNS to your server
3. Run SSL setup script

### Cloudflare WAF
1. Import rules from `cloudflare-waf-rules.json`
2. Configure IP whitelists
3. Set up page rules for caching

## 🔧 Server Requirements

- **OS**: Ubuntu 20.04+ / Debian 11+
- **RAM**: 2GB minimum, 4GB recommended
- **Storage**: 20GB minimum
- **Network**: Static IP address
- **Ports**: 22 (SSH), 80 (HTTP), 443 (HTTPS)

## 📊 Monitoring

### Log Files
- Application: `/var/log/nginx/jtc-fashion.*.log`
- Firewall: `/var/log/ufw.log`
- Security: `/var/log/fail2ban.log`

### Health Checks
- Application: `https://your-domain.com/health`
- SSL Certificate: `openssl x509 -in /etc/letsencrypt/live/your-domain.com/cert.pem -noout -dates`

### Commands
```bash
# Check firewall status
sudo ufw status verbose

# Check fail2ban status
sudo fail2ban-client status

# Check SSL certificate
sudo certbot certificates

# Test nginx configuration
sudo nginx -t

# View real-time logs
sudo tail -f /var/log/nginx/jtc-fashion.access.log
```

## 🔄 Maintenance

### SSL Certificate Renewal
Automatic renewal is configured via cron. Manual renewal:
```bash
sudo certbot renew
sudo systemctl reload nginx
```

### Security Updates
```bash
sudo apt update && sudo apt upgrade -y
npm audit fix
```

### Backup
```bash
# Database backup
pg_dump -U username database_name > backup.sql

# Application backup
tar -czf backup-$(date +%Y%m%d).tar.gz /var/www/jtc-fashion
```

## 🛡️ Security Checklist

- [ ] SSL certificate installed and auto-renewal configured
- [ ] UFW firewall enabled with proper rules
- [ ] Fail2ban configured and running
- [ ] Environment variables secured (600 permissions)
- [ ] Cloudflare WAF rules active
- [ ] Security headers implemented
- [ ] Rate limiting configured
- [ ] Regular security updates scheduled
- [ ] Monitoring and alerting set up
- [ ] Backup strategy implemented

## 📞 Support

For security issues or deployment questions:
- Check logs first: `sudo tail -f /var/log/nginx/jtc-fashion.error.log`
- Review firewall: `sudo ufw status verbose`
- Test SSL: `https://www.ssllabs.com/ssltest/`

## 📄 License

Private - All rights reserved

---

**⚠️ Security Notice**: Always keep your system updated and monitor logs regularly. Never commit `.env` files to version control.